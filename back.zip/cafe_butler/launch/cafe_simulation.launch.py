
import os

from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    DeclareLaunchArgument,
    TimerAction
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    LaunchConfiguration,
    Command,
    PathJoinSubstitution
)

from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():

    #################################################
    # Package name
    #################################################
    pkg_name = "cafe_butler"

    #################################################
    # File paths
    #################################################
    urdf_file = PathJoinSubstitution([
        FindPackageShare(pkg_name),
        "urdf",
        "my_robot.urdf.xacro"
    ])

    rviz_config = PathJoinSubstitution([
        FindPackageShare(pkg_name),
        "rviz",
        "urdf_vis1.rviz"
    ])

    world_file = PathJoinSubstitution([
        FindPackageShare(pkg_name),
        "worlds",
        "cafe_1.world"
    ])

    ekf_config = PathJoinSubstitution([
        FindPackageShare(pkg_name),
        "config",
        "ekf.yaml"
    ])



    map_file = PathJoinSubstitution([
        FindPackageShare(pkg_name),
        "maps",
        "cafe_map.yaml"
    ])

    #################################################
    # Launch Arguments
    #################################################
    use_sim_time = LaunchConfiguration("use_sim_time")

    declare_use_sim_time = DeclareLaunchArgument(
        "use_sim_time",
        default_value="true"
    )

    #################################################
    # Robot State Publisher
    #################################################
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[
            {
                "use_sim_time": use_sim_time,
                "robot_description": Command(
                    ["xacro", " ", urdf_file]
                )
            }
        ]
    )

    #################################################
    # Joint State Publisher
    #################################################
    joint_state_publisher = Node(
        package="joint_state_publisher",
        executable="joint_state_publisher",
        name="joint_state_publisher",
        output="screen",
        parameters=[
            {
                "use_sim_time": use_sim_time
            }
        ]
    )    

    #################################################
    # Gazebo
    #################################################
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("gazebo_ros"),
                "launch",
                "gazebo.launch.py"
            ])
        ),
        launch_arguments={
            "world": world_file,
            "verbose": "true"
        }.items()
    )

    #################################################
    # Spawn Robot
    #################################################
    spawn_robot = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        name="spawn_entity",
        output="screen",
        arguments=[
            "-topic",
            "robot_description",
            "-entity",
            "cafe_butler"
        ]
    )

    delayed_spawn = TimerAction(
        period=5.0,
        actions=[spawn_robot]
    )

    #################################################
    # EKF Localization
    #################################################
    ekf_node = Node(
        package="robot_localization",
        executable="ekf_node",
        name="ekf_filter_node",
        output="screen",
        parameters=[
            ekf_config,
            {
                "use_sim_time": use_sim_time
            }
        ]
    )

    #################################################
    # RViz2
    #################################################
    rviz = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=[
            "-d",
            rviz_config
        ],
        parameters=[
            {
                "use_sim_time": use_sim_time
            }
        ]
    )

    #################################################
    # Teleop
    #################################################
    teleop = Node(
        package="teleop_twist_keyboard",
        executable="teleop_twist_keyboard",
        prefix="xterm -e",
        output="screen"
    )

    # #################################################
    # # Nav2 Bringup
    # #################################################
    # nav2 = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         PathJoinSubstitution([
    #             FindPackageShare('nav2_bringup'),
    #             'launch',
    #             'bringup_launch.py'
    #         ])
    #     ),
    #     launch_arguments={
    #         'map': map_file,
    #         'use_sim_time': 'true',
    #         'autostart': 'true'
    #     }.items()
    # )

    #################################################
    # Launch Description
    #################################################
    return LaunchDescription([

        declare_use_sim_time,

        joint_state_publisher,

        robot_state_publisher,

        gazebo,

        delayed_spawn,

        ekf_node,

        rviz,

        teleop,

        # nav2,
    ])
